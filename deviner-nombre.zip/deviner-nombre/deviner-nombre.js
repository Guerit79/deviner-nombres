import { DevinerNombre } from './src/DevinerNombre.js';

window.customElements.define('deviner-nombre', DevinerNombre);
