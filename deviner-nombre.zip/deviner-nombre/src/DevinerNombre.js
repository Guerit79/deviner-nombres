import { html, css, LitElement } from 'lit-element';

export class DevinerNombre extends LitElement {
  static get styles() {
    return css`
      :host {
        display: block;
        padding: 25px;
        color: var(--deviner-nombre-text-color, #000); 
      }
    `;
  }

  static get properties() {
    return {
      range : { type: Number },
      rand : { type: Number },
      lifes : { type: Number },
      message : { type: String },
      currentValue  : {type: Number},
      isWin  : {type: Boolean}
    };
  }

  constructor() {
    super();
    this.range = 10;  // Nombre x => le nombre de vie total & nombre rand max à ne pas dépasser
    this.rand = parseInt(Math.floor(Math.random() * (this.range+1))); // Définition du nombre à trouver
    this.lifes = this.range;  // Définition du nombres de vies
    this.message = '';  // Message d'erreurs 
    this.currentValue = 0;
    this.isWin = false;
  }

  __affect(value) 
  {
    this.currentValue = value.target.value;
  }

  /**
   * Jouer un tour de partie
   * Return void => une seule affection de variable (__message)
   */

  __restart()
  {

    // Reset fields

    this.range = 10;
    this.rand = parseInt(Math.floor(Math.random() * (this.range+1)));
    this.lifes = this.range;
    this.message = '';
    this.currentValue = 0;
    this.isWin = false;


  }

  __play() 
  {

    // Get input data 
    const input = parseInt(this.currentValue);

    // Verify if it's lose

    if (parseInt(this.lifes) <= 0){
      return this.message = 'Perdu !';
    }

    // Check datas

    if (input < this.rand){
      this.message = 'Trop petit';
      this.lifes-=1;
    } else if (input > this.rand) {
      this.message = 'Trop grand';
      this.lifes-=1;
    } else {
      this.message = 'Trouvé';
    }

  }

  render() {
    return html`

      <h2>Deviner mon nombre (entre 0 et ${this.range})!</h2>
      <br/>
      <h4>Nombre de vie :${this.lifes}</h4>
      <h4>${this.message}</h4>
      <input id="number_input" placeholder="Entrer un nombre" @change=${e => this.__affect(e)}/>
      <button @click=${this.__play}>OK</button>
      <button @click=${this.__restart}>Rejouer</button>

    `;
  }
}
