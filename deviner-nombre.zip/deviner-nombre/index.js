export { DevinerNombre } from './src/DevinerNombre.js';
